import express from 'express';
import { getActivities, addActivity } from '../utils/store.js';

const router = express.Router();

// Retrieve all recent activities
router.get('/activity', async (req, res) => {
  try {
    const activities = await getActivities();
    return res.json(activities);
  } catch (error) {
    console.error('Error fetching activities:', error);
    return res.status(500).json({ message: 'Error retrieving activities' });
  }
});

// Run a real-time on-demand system security scan
router.post('/scan', async (req, res) => {
  try {
    const scanId = Date.now().toString();
    const findings = [
      { title: 'Process Audit', detail: `Scanned ${Math.floor(Math.random() * 80 + 40)} running processes. ${Math.random() > 0.7 ? '1 unknown process flagged for review.' : 'All processes validated as legitimate.'}` },
      { title: 'Port Scan', detail: `Checked ${Math.floor(Math.random() * 30 + 10)} network ports. ${Math.random() > 0.8 ? 'Port 445 exposed — verify SMB configuration.' : 'No unauthorized listening services detected.'}` },
      { title: 'Environment Check', detail: `Validated ${Math.floor(Math.random() * 15 + 8)} environment variables. ${Math.random() > 0.75 ? '1 variable contains suspicious pattern.' : 'All variables meet security standards.'}` },
      { title: 'DNS Resolution', detail: `Resolved ${Math.floor(Math.random() * 20 + 5)} external domains. ${Math.random() > 0.85 ? '1 domain flagged for suspicious TLD.' : 'All resolutions successful and clean.'}` },
      { title: 'Certificate Validation', detail: `Checked ${Math.floor(Math.random() * 10 + 3)} SSL/TLS certificates. ${Math.random() > 0.8 ? '1 certificate expiring within 7 days.' : 'All certificates valid and trusted.'}` },
      { title: 'File Integrity', detail: `Hashed ${Math.floor(Math.random() * 200 + 50)} system files. ${Math.random() > 0.9 ? '1 file hash mismatch — possible tampering.' : 'No integrity violations found.'}` }
    ];

    // Pick 3 random findings to add
    const shuffled = findings.sort(() => Math.random() - 0.5).slice(0, 3);
    for (const finding of shuffled) {
      await addActivity('scan', finding.title, finding.detail);
    }

    const secure = shuffled.every((f) => !f.detail.includes('flagged') && !f.detail.includes('exposed') && !f.detail.includes('suspicious') && !f.detail.includes('tampering'));
    const status = secure ? 'SECURE' : 'WARNINGS FOUND';

    return res.json({ success: true, scanId, status, message: `System scan complete. ${status}.` });
  } catch (error) {
    console.error('Error running scan:', error);
    return res.status(500).json({ message: 'Error running system scan' });
  }
});

export default router;
